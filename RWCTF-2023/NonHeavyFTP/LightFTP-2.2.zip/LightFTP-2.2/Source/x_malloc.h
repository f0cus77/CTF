/*
 * x_malloc.h
 *
 *  Created on: Feb 3, 2018
 *      Author: lightftp
 */

#ifndef X_MALLOC_H_
#define X_MALLOC_H_

void * x_malloc(size_t size);

#endif /* X_MALLOC_H_ */
